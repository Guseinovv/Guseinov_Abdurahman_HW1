package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        //Задание N1
        String love_java;
        //Задание N2
        final int NUM = 5;
        //Задание N3
        String word  = "Verbum";
        //Задание N4
        love_java = (word + " " + NUM);
        //Задание N5
        System.out.println(love_java);
        //Задание N6
        if (NUM < 0){
            System.out.println("Вы сохранили отрицательное число");

        if (NUM > 0)
            System.out.println("Вы сохранили положительное число");

        if (NUM == 0)
            System.out.println("Вы сохрнили ноль");
        }

        Scanner scanner = new Scanner(System.in);
        System.out.println("ведите ваше имя");
        System.out.println("привет"+ " "+ scanner.nextLine());

    }
}
